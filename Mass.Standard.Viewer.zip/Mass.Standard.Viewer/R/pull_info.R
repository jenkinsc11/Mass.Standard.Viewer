#' The Pull Info Function
#'
#' this function pulls the relevant data out of a Proteome discoverer 2.2 .csv output. The file of interest is any PD output that
#' you would like and the Accession must be the name of the Accession of your QC peptide
#'
#' @name pull_info
#' @param file_of_interest is the raw data pulled in defined above
#' @param Accesson is the accesion number of your QC peptide
#' @export

pull_info <- function(file_of_interest, Accession){
  raw_data <- read.table(file_of_interest, header = TRUE)
  QC_filter <- raw_data[raw_data$Protein.Accessions==Accession,]
  relevant_data <- select(QC_filter, Sequence, Delta.M.in.ppm.by.Search.Engine.Sequest.HT, RT.in.min.by.Search.Engine.Sequest.HT, XCorr.by.Search.Engine.Sequest.HT)
  return (relevant_data)
}

