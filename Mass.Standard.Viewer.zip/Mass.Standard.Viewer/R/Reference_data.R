#'Reference Data
#'
#'This dataset was collected using the Thermo PTRC peptides run on a recently Cleaned and Calibrated QE HF Mass Spectrometer using a 67min gradient and an Easy nano 1000 LC
#'
#'@name Reference_Data
#'@param RT is retention time
#'@param Delta.M is the shift in mass from a perfect ID Mass
#'@param Sequence is the identified sequence of the retention time peptides
#'@param Xcorr is the scoring metric from the search algorithm identification
#'
NULL
