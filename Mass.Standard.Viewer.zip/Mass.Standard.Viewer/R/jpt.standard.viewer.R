#'Retention Time Graphical Representation
#'
#'This function graphically represents the shift in retention time, mass and xcorr given by the search engine.
#'
#' @name ret.time.plot
#' @param standard_file is the standard file that should be your reference QC standard
#' @param test_file is the qc run that you want to test against your standard file
#' @param accession is the accession number of your QC item in your fasta file
#' @param standard_color is the color of the points of your standard_file
#' @param test_color is the color of the points of your test_file
#' @export

ret.time.plot <- function(standard_file, test_file, accession, standard_color = "#E69F00", test_color = "#56B4E9"){
  standard_file$group <- "Standard"
  test_file$group <- "Test"
  combined_data<- full_join(standard_file,test_file, by = c('Sequence', 'Delta.M.in.ppm.by.Search.Engine.Sequest.HT', 'RT.in.min.by.Search.Engine.Sequest.HT', 'XCorr.by.Search.Engine.Sequest.HT', 'group'))
  graphic <- ggplot(combined_data,aes(x=RT.in.min.by.Search.Engine.Sequest.HT, y=Delta.M.in.ppm.by.Search.Engine.Sequest.HT, color = group))
  scatter_plot <- graphic + geom_point(alpha =0.50, size = combined_data$XCorr.by.Search.Engine.Sequest.HT)
  final_plot <- scatter_plot + scale_color_manual(values = c(standard_color, test_color))
  print(final_plot + geom_label_repel(aes(label= combined_data$Sequence), box.padding = 1, point.padding = .5) + theme_classic())
  kable(arrange(combined_data, Sequence))
}

