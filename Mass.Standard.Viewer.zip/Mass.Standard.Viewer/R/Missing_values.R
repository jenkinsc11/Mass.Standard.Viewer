#' Plot the Difference in Retention Time
#'
#' This fuction plots the difference in retention time between two mass spec standard runs
#'
#' @name ret.time.diff
#' @param standard_file the standard run data frame that was created with the pull_info function
#' @param test_file the test run data frame that was created with the pull_info function
#' @param standard_color is the color of the bar graph
#' @export

ret.time.diff <- function(standard_file, test_file, standard_color = "#E69F00"){
  standard_file$group <- "Standard"
  test_file$group <- "Test"
  combined_data<- left_join(standard_file,test_file, by = c('Sequence'))
  combined_data$RT.Diff <- combined_data$RT.in.min.by.Search.Engine.Sequest.HT.x - combined_data$RT.in.min.by.Search.Engine.Sequest.HT.y
  combined_data <- na.omit(combined_data)
  graphic <- ggplot(combined_data,aes(x=Sequence, y=RT.Diff, fill=standard_color)) + geom_bar(stat = "identity")
  print(graphic + theme(axis.text.x = element_text(angle = 90, hjust = 1)))
}
