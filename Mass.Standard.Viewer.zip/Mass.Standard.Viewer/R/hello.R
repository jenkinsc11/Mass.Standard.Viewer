# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

hello <- function() {
  print("Hello, world!")
}



library(dplyr)
library(ggplot2)
library(ggrepel)
library(readr)
library(knitr)
library(grid)

Reference_Data <- 'Procal_Standard_PeptideGroups.txt'
Test_Data <- 'Procal_SOAP_PeptideGroups.txt'
Accession <- "QC"

Reference_Data <- 'Procal_Standard_PeptideGroups.txt'
Test_Data <- 'Procal_SOAP_PeptideGroups.txt'

pull_info <- function(file_of_interest, Accession){
  raw_data <- read.table(file_of_interest, header = TRUE)
  QC_filter <- raw_data[raw_data$Protein.Accessions==Accession,]
  relevant_data <- select(QC_filter, Sequence, Delta.M.in.ppm.by.Search.Engine.Sequest.HT, RT.in.min.by.Search.Engine.Sequest.HT, XCorr.by.Search.Engine.Sequest.HT)
  return (relevant_data)
}


x <- pull_info(Reference_Data, "QC")
y <- pull_info(Test_Data, "QC")





